@rem Gradle startup script for Windows
@if "%DEBUG%" == "" @echo off
@rem ##########################################################################
@rem
@rem  Gradle startup script for Windows
@rem
@rem ##########################################################################
set DIRNAME=%~dp0
if "%DIRNAME%" == "" set DIRNAME=.
set APP_BASE_NAME=%~n0
set APP_HOME=%DIRNAME%
set GRADLE_USER_HOME=%APP_HOME%\.gradle
set GRADLE_OPTS=-Dorg.gradle.appname=%APP_BASE_NAME%
set JAVA_EXE=java.exe
if not defined JAVA_HOME goto findJavaFromJavaHome
set JAVA_EXE=%JAVA_HOME%\bin\java.exe
goto execute
:findJavaFromJavaHome
set JAVA_EXE=java.exe
:execute
@rem Setup the command line
set CLASSPATH=%APP_HOME%\gradle\wrapper\gradle-wrapper.jar
@rem Execute Gradle
"%JAVA_EXE%" %GRADLE_OPTS% -classpath "%CLASSPATH%" org.gradle.wrapper.GradleWrapperMain %*
