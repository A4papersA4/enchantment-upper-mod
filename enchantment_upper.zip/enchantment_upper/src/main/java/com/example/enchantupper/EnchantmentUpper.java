﻿package com.example.enchantupper;

import com.example.enchantupper.event.AnvilHandler;
import net.neoforged.fml.common.Mod;
import net.neoforged.fml.loading.FMLPaths;
import net.neoforged.neoforge.common.NeoForge;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

@Mod(EnchantmentUpper.MODID)
public class EnchantmentUpper {
    public static final String MODID = "enchantment_upper";
    public static final Logger LOGGER = LogManager.getLogger();

    public EnchantmentUpper() {
        Config.load(FMLPaths.CONFIGDIR.get().resolve("enchantment_upper.toml"));
        NeoForge.EVENT_BUS.register(new AnvilHandler());
        LOGGER.info("Enchantment Upper loaded – break the limits via anvil!");
    }
}
