﻿package com.example.enchantupper.mixin;

import com.example.enchantupper.Config;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.enchantment.Enchantment;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(Enchantment.class)
public class MixinEnchantment {
    @Inject(method = "getMaxLevel", at = @At("HEAD"), cancellable = true)
    private void overrideMaxForEnchantingTable(CallbackInfoReturnable<Integer> cir) {
        if (!Config.ALLOW_ENCHANTING_TABLE.get()) return;

        Enchantment self = (Enchantment)(Object)this;
        ResourceLocation id = BuiltInRegistries.ENCHANTMENT.getKey(self);
        if (id != null) {
            Integer max = Config.ENCHANTMENT_MAX_LEVELS.get(id.toString());
            if (max == null) {
                max = Config.DEFAULT_MAX_LEVEL.get();
            }
            cir.setReturnValue(max);
        }
    }
}
