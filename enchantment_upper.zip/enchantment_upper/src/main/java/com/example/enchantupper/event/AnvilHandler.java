﻿package com.example.enchantupper.event;

import com.example.enchantupper.Config;
import com.example.enchantupper.Config.CostMode;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.EnchantedBookItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import net.neoforged.neoforge.event.AnvilUpdateEvent;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.bus.api.EventPriority;

import java.util.HashMap;
import java.util.Map;

public class AnvilHandler {

    @SubscribeEvent(priority = EventPriority.LOW)
    public void onAnvilUpdate(AnvilUpdateEvent event) {
        if (!Config.ENABLE_ANVIL_BREAKTHROUGH.get() || !event.getOutput().isEmpty()) {
            return;
        }

        ItemStack left = event.getLeft();
        ItemStack right = event.getRight();
        if (left.isEmpty() || right.isEmpty()) return;
        if (!(right.getItem() instanceof EnchantedBookItem)) return;

        Map<Enchantment, Integer> maxLevels = new HashMap<>();
        for (Enchantment ench : BuiltInRegistries.ENCHANTMENT) {
            ResourceLocation id = BuiltInRegistries.ENCHANTMENT.getKey(ench);
            if (id == null) continue;
            int max = Config.ENCHANTMENT_MAX_LEVELS.getOrDefault(id.toString(), Config.DEFAULT_MAX_LEVEL.get());
            maxLevels.put(ench, max);
        }

        Map<Enchantment, Integer> leftEnchants = EnchantmentHelper.getEnchantments(left);
        Map<Enchantment, Integer> bookEnchants = EnchantmentHelper.getEnchantments(right);

        ItemStack result = left.copy();
        Map<Enchantment, Integer> finalEnchants = new HashMap<>(leftEnchants);
        boolean modified = false;
        int cost = 0;

        for (Map.Entry<Enchantment, Integer> bookEntry : bookEnchants.entrySet()) {
            Enchantment ench = bookEntry.getKey();
            int bookLevel = bookEntry.getValue();
            if (!ench.canEnchant(result)) continue;

            boolean conflict = false;
            for (Enchantment existing : finalEnchants.keySet()) {
                if (existing != ench && !EnchantmentHelper.isEnchantmentCompatible(existing, ench)) {
                    conflict = true;
                    break;
                }
            }
            if (conflict) continue;

            int existingLevel = finalEnchants.getOrDefault(ench, 0);
            int configMax = maxLevels.getOrDefault(ench, Config.DEFAULT_MAX_LEVEL.get());
            int newLevel;

            if (bookLevel > existingLevel) {
                newLevel = Math.min(bookLevel, configMax);
            } else if (bookLevel == existingLevel) {
                newLevel = Math.min(existingLevel + 1, configMax);
            } else {
                newLevel = existingLevel;
            }

            if (newLevel != existingLevel) {
                finalEnchants.put(ench, newLevel);
                cost += newLevel;
                modified = true;
            }
        }

        if (modified) {
            EnchantmentHelper.setEnchantments(result, finalEnchants);
            event.setOutput(result);

            CostMode mode = Config.ANVIL_COST_MODE.get();
            if (mode == CostMode.FREE) {
                event.setCost(0);
                event.setMaterialCost(0);
            } else if (mode == CostMode.ADAPTIVE) {
                event.setCost(0);
                event.setMaterialCost(1);
            } else {
                event.setCost(cost);
                event.setMaterialCost(1);
            }
        }
    }
}
