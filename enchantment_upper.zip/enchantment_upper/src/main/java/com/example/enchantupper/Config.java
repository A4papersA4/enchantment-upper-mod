﻿package com.example.enchantupper;

import com.electronwill.nightconfig.core.file.CommentedFileConfig;
import com.electronwill.nightconfig.core.io.WritingMode;
import net.neoforged.neoforge.common.ModConfigSpec;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.nio.file.Path;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Config {
    private static final Logger LOGGER = LogManager.getLogger();
    public static final Map<String, Integer> ENCHANTMENT_MAX_LEVELS = new HashMap<>();

    public static ModConfigSpec.BooleanValue ENABLE_ANVIL_BREAKTHROUGH;
    public static ModConfigSpec.EnumValue<CostMode> ANVIL_COST_MODE;
    public static ModConfigSpec.IntValue DEFAULT_MAX_LEVEL;
    public static ModConfigSpec.BooleanValue ALLOW_ENCHANTING_TABLE;
    private static ModConfigSpec.ConfigValue<List<? extends String>> MAX_LEVELS;

    public enum CostMode {
        NORMAL,
        FREE,
        ADAPTIVE
    }

    private static final ModConfigSpec.Builder BUILDER = new ModConfigSpec.Builder();
    public static final ModConfigSpec SPEC;

    private static List<String> defaultMaxLevels() {
        return List.of(
            "minecraft:sharpness=10", "minecraft:smite=10", "minecraft:bane_of_arthropods=10",
            "minecraft:knockback=5", "minecraft:fire_aspect=5", "minecraft:looting=5",
            "minecraft:sweeping=5", "minecraft:efficiency=10", "minecraft:silk_touch=1",
            "minecraft:unbreaking=5", "minecraft:fortune=5", "minecraft:power=10",
            "minecraft:punch=5", "minecraft:flame=1", "minecraft:infinity=1",
            "minecraft:protection=10", "minecraft:fire_protection=10", "minecraft:feather_falling=10",
            "minecraft:blast_protection=10", "minecraft:projectile_protection=10",
            "minecraft:respiration=5", "minecraft:aqua_affinity=1", "minecraft:depth_strider=5",
            "minecraft:frost_walker=5", "minecraft:binding_curse=1", "minecraft:vanishing_curse=1",
            "minecraft:loyalty=5", "minecraft:impaling=10", "minecraft:riptide=5",
            "minecraft:channeling=1", "minecraft:multishot=1", "minecraft:quick_charge=5",
            "minecraft:piercing=5", "minecraft:thorns=5", "minecraft:mending=1",
            "minecraft:swift_sneak=5", "minecraft:soul_speed=5"
        );
    }

    static {
        BUILDER.comment("Enchantment Upper - Compatibility Edition");
        ENABLE_ANVIL_BREAKTHROUGH = BUILDER
            .comment("If true, anvil can break enchantment limits. Set to false if another mod handles anvil upgrades.")
            .define("enable_anvil_breakthrough", true);
        ANVIL_COST_MODE = BUILDER
            .comment("Anvil cost mode: NORMAL (default), FREE (no cost), ADAPTIVE (avoid double cost with other mods)")
            .defineEnum("anvil_cost_mode", CostMode.NORMAL);
        ALLOW_ENCHANTING_TABLE = BUILDER
            .comment("If true, enchanting table can directly give high levels.")
            .define("allow_enchanting_table", false);
        DEFAULT_MAX_LEVEL = BUILDER
            .comment("Default max level for any enchantment NOT listed in max_levels (supports mod-added enchantments).")
            .defineInRange("default_max_level", 10, 1, 255);
        BUILDER.push("max_levels");
        MAX_LEVELS = BUILDER
            .comment("Override max level for specific enchantments. Format: 'modid:enchantment=level'")
            .defineList("overrides", defaultMaxLevels(), entry -> entry instanceof String && ((String)entry).matches("[a-z0-9_.-]+:[a-z_]+=\\\d+"));
        BUILDER.pop();
        SPEC = BUILDER.build();
    }

    public static void load(Path path) {
        final CommentedFileConfig config = CommentedFileConfig.builder(path)
            .sync().autosave().writingMode(WritingMode.REPLACE).build();
        config.load();
        SPEC.setConfig(config);

        ENCHANTMENT_MAX_LEVELS.clear();
        List<? extends String> list = MAX_LEVELS.get();
        for (String entry : list) {
            String[] parts = entry.split("=");
            if (parts.length == 2) {
                try {
                    int lvl = Integer.parseInt(parts[1]);
                    if (lvl > 0) ENCHANTMENT_MAX_LEVELS.put(parts[0], lvl);
                } catch (NumberFormatException e) {
                    LOGGER.error("Invalid max level entry: {}", entry);
                }
            }
        }
        LOGGER.info("Loaded {} enchantment overrides, default max: {}", ENCHANTMENT_MAX_LEVELS.size(), DEFAULT_MAX_LEVEL.get());
    }
}
